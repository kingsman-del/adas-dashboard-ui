"use client";

import React, { useState, useCallback, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
} from "recharts";

// Types
interface CarSettings {
  suspension_height_mm: number;
  suspension_stiffness: number;
  damping_rate: number;
  max_speed_kmh: number;
  acceleration_rate: number;
  traction_control: number;
  torque_distribution: string;
  brake_sensitivity: number;
  abs_aggressiveness: number;
  steering_responsiveness: number;
  safe_following_distance_m: number;
  emergency_stop: boolean;
  terrain_mode: string;
  alert_message: string;
  urgency_level: number;
}

interface ApiResponse {
  annotated_image_base64: string;
  terrain_mode: string;
  alert: string;
  urgency: number;
  car_settings: CarSettings;
}

const defaultSettings: CarSettings = {
  suspension_height_mm: 200,
  suspension_stiffness: 0.5,
  damping_rate: 0.5,
  max_speed_kmh: 120,
  acceleration_rate: 0.7,
  traction_control: 0.5,
  torque_distribution: "AWD",
  brake_sensitivity: 0.5,
  abs_aggressiveness: 0.5,
  steering_responsiveness: 0.5,
  safe_following_distance_m: 50,
  emergency_stop: false,
  terrain_mode: "SPORT",
  alert_message: "System Ready",
  urgency_level: 0,
};

// Animated Number Component
function AnimatedNumber({ value, decimals = 0 }: { value: number; decimals?: number }) {
  const [displayValue, setDisplayValue] = useState(value);
  const prevValue = useRef(value);

  useEffect(() => {
    const start = prevValue.current;
    const end = value;
    const duration = 800;
    const startTime = Date.now();

    const animate = () => {
      const elapsed = Date.now() - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setDisplayValue(start + (end - start) * eased);
      
      if (progress < 1) {
        requestAnimationFrame(animate);
      }
    };

    requestAnimationFrame(animate);
    prevValue.current = value;
  }, [value]);

  return <>{displayValue.toFixed(decimals)}</>;
}

// Circular Gauge Component
function CircularGauge({ 
  value, 
  maxValue = 1, 
  label, 
  unit = "", 
  color = "#00d2ff",
  size = "large"
}: { 
  value: number; 
  maxValue?: number; 
  label: string; 
  unit?: string; 
  color?: string;
  size?: "large" | "small";
}) {
  const percentage = Math.min((value / maxValue) * 100, 100);
  const radius = size === "large" ? 80 : 35;
  const strokeWidth = size === "large" ? 10 : 6;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (percentage / 100) * circumference * 0.75;
  const svgSize = size === "large" ? 200 : 90;

  return (
    <div className="relative flex flex-col items-center">
      <svg 
        width={svgSize} 
        height={svgSize} 
        className="transform -rotate-135"
      >
        {/* Background arc */}
        <circle
          cx={svgSize / 2}
          cy={svgSize / 2}
          r={radius}
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth={strokeWidth}
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
          strokeLinecap="round"
        />
        {/* Animated value arc */}
        <motion.circle
          cx={svgSize / 2}
          cy={svgSize / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth={strokeWidth}
          strokeDasharray={`${circumference * 0.75} ${circumference * 0.25}`}
          strokeLinecap="round"
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          style={{
            filter: `drop-shadow(0 0 8px ${color})`,
          }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span 
          className={`font-[var(--font-heading)] font-bold ${size === "large" ? "text-3xl" : "text-sm"}`}
          style={{ color }}
        >
          <AnimatedNumber value={value} decimals={maxValue <= 1 ? 2 : 0} />
          {unit}
        </span>
        <span className={`text-muted-foreground ${size === "large" ? "text-sm" : "text-[10px]"} mt-1 text-center`}>
          {label}
        </span>
      </div>
    </div>
  );
}

// Vehicle SVG Component
function VehicleSVG({ 
  settings, 
  isShaking 
}: { 
  settings: CarSettings; 
  isShaking: boolean;
}) {
  const suspensionNormalized = (settings.suspension_height_mm - 160) / 100;
  const liftAmount = suspensionNormalized * 15;
  const wheelSpread = suspensionNormalized * 5;
  
  const urgencyColor = settings.urgency_level === 0 ? "#00ff88" 
    : settings.urgency_level === 1 ? "#ffaa00" 
    : settings.urgency_level === 2 ? "#ff8800" 
    : "#ff3b3b";

  return (
    <motion.svg
      viewBox="0 0 300 150"
      className="w-full max-w-[300px]"
      animate={isShaking ? {
        x: [0, -2, 2, -2, 2, 0],
        y: [0, -1, 1, -1, 1, 0],
      } : {}}
      transition={isShaking ? {
        duration: 0.3,
        repeat: Infinity,
      } : {}}
    >
      {/* Car body - main */}
      <motion.g
        animate={{ y: -liftAmount }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        {/* Body shadow */}
        <ellipse cx="150" cy="120" rx="100" ry="10" fill="rgba(0,0,0,0.3)" />
        
        {/* Main body */}
        <motion.path
          d="M50 80 L70 50 L120 40 L180 40 L230 50 L250 80 L250 100 L50 100 Z"
          fill="url(#bodyGradient)"
          stroke={urgencyColor}
          strokeWidth="2"
          animate={{
            filter: settings.emergency_stop 
              ? ["drop-shadow(0 0 10px #ff3b3b)", "drop-shadow(0 0 20px #ff3b3b)"]
              : `drop-shadow(0 0 5px ${urgencyColor})`
          }}
          transition={settings.emergency_stop ? {
            duration: 0.5,
            repeat: Infinity,
            repeatType: "reverse"
          } : {}}
        />
        
        {/* Roof */}
        <path
          d="M90 50 L100 30 L200 30 L210 50"
          fill="none"
          stroke="#00d2ff"
          strokeWidth="2"
          opacity="0.5"
        />
        
        {/* Windows */}
        <path
          d="M95 48 L105 35 L195 35 L205 48 Z"
          fill="rgba(0, 210, 255, 0.2)"
          stroke="#00d2ff"
          strokeWidth="1"
        />
        
        {/* Headlights */}
        <motion.ellipse
          cx="245"
          cy="75"
          rx="8"
          ry="6"
          fill={urgencyColor}
          animate={{
            opacity: settings.emergency_stop ? [1, 0.3] : 1,
            filter: `drop-shadow(0 0 10px ${urgencyColor})`
          }}
          transition={settings.emergency_stop ? {
            duration: 0.3,
            repeat: Infinity,
            repeatType: "reverse"
          } : {}}
        />
        <motion.ellipse
          cx="55"
          cy="75"
          rx="8"
          ry="6"
          fill="#ff3333"
          opacity="0.8"
        />
        
        {/* Grille lines */}
        <g stroke="#00d2ff" strokeWidth="1" opacity="0.6">
          <line x1="235" y1="85" x2="250" y2="85" />
          <line x1="235" y1="90" x2="250" y2="90" />
          <line x1="235" y1="95" x2="250" y2="95" />
        </g>
      </motion.g>
      
      {/* Wheels */}
      <motion.g
        animate={{ y: -liftAmount }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        {/* Front wheel */}
        <motion.g
          animate={{ x: wheelSpread }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <circle cx="210" cy="105" r="18" fill="#1a1a1a" stroke="#333" strokeWidth="3" />
          <circle cx="210" cy="105" r="10" fill="#00d2ff" opacity="0.3" />
          <motion.circle
            cx="210"
            cy="105"
            r="14"
            fill="none"
            stroke="#00d2ff"
            strokeWidth="2"
            strokeDasharray="4 4"
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "210px 105px" }}
          />
        </motion.g>
        
        {/* Rear wheel */}
        <motion.g
          animate={{ x: -wheelSpread }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <circle cx="90" cy="105" r="18" fill="#1a1a1a" stroke="#333" strokeWidth="3" />
          <circle cx="90" cy="105" r="10" fill="#00d2ff" opacity="0.3" />
          <motion.circle
            cx="90"
            cy="105"
            r="14"
            fill="none"
            stroke="#00d2ff"
            strokeWidth="2"
            strokeDasharray="4 4"
            animate={{ rotate: 360 }}
            transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
            style={{ transformOrigin: "90px 105px" }}
          />
        </motion.g>
      </motion.g>
      
      {/* Exhaust particles when speed is high */}
      {settings.max_speed_kmh > 100 && (
        <g>
          {[...Array(5)].map((_, i) => (
            <motion.circle
              key={i}
              cx={40}
              cy={95}
              r={3}
              fill="#00d2ff"
              opacity={0.6}
              animate={{
                x: [-10 - i * 10, -50 - i * 10],
                opacity: [0.6, 0],
                scale: [1, 0.5],
              }}
              transition={{
                duration: 1,
                repeat: Infinity,
                delay: i * 0.2,
              }}
            />
          ))}
        </g>
      )}
      
      {/* Gradients */}
      <defs>
        <linearGradient id="bodyGradient" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor="#2a2a35" />
          <stop offset="50%" stopColor="#1a1a25" />
          <stop offset="100%" stopColor="#0a0a15" />
        </linearGradient>
      </defs>
    </motion.svg>
  );
}

// Terrain Background Component
function TerrainBackground({ mode }: { mode: string }) {
  const getTerrainStyle = () => {
    switch (mode) {
      case "SPORT":
        return (
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute bottom-0 left-0 right-0 h-1/3 bg-gradient-to-t from-gray-800 to-transparent" />
            {/* Road lines */}
            {[...Array(5)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute h-1 bg-white/30 rounded"
                style={{
                  bottom: "10%",
                  left: `${10 + i * 20}%`,
                  width: "40px",
                }}
                animate={{ x: [0, -100] }}
                transition={{
                  duration: 1,
                  repeat: Infinity,
                  delay: i * 0.2,
                  ease: "linear",
                }}
              />
            ))}
          </div>
        );
      case "OFFROAD":
        return (
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-amber-900/50 to-transparent" />
            {/* Dust particles */}
            {[...Array(20)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute w-1 h-1 bg-amber-600/60 rounded-full"
                style={{
                  bottom: `${Math.random() * 30 + 10}%`,
                  left: `${Math.random() * 100}%`,
                }}
                animate={{
                  y: [0, -20],
                  opacity: [0.6, 0],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  delay: i * 0.1,
                }}
              />
            ))}
          </div>
        );
      case "ROUGH":
        return (
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-stone-700/50 to-transparent" />
            {/* Rocks */}
            {[...Array(8)].map((_, i) => (
              <div
                key={i}
                className="absolute bg-stone-600/40 rounded"
                style={{
                  bottom: `${5 + Math.random() * 15}%`,
                  left: `${5 + i * 12}%`,
                  width: `${10 + Math.random() * 15}px`,
                  height: `${8 + Math.random() * 10}px`,
                }}
              />
            ))}
          </div>
        );
      case "HAZARD":
        return (
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute bottom-0 left-0 right-0 h-1/2 bg-gradient-to-t from-blue-900/40 to-transparent" />
            {/* Water ripples */}
            {[...Array(3)].map((_, i) => (
              <motion.div
                key={i}
                className="absolute border border-blue-400/30 rounded-full"
                style={{
                  bottom: "15%",
                  left: `${30 + i * 15}%`,
                  width: "60px",
                  height: "20px",
                }}
                animate={{
                  scale: [1, 1.5],
                  opacity: [0.5, 0],
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  delay: i * 0.5,
                }}
              />
            ))}
          </div>
        );
      case "EMERGENCY":
        return (
          <div className="absolute inset-0 overflow-hidden">
            <motion.div
              className="absolute inset-0 bg-red-900/20"
              animate={{ opacity: [0.2, 0.4] }}
              transition={{ duration: 0.5, repeat: Infinity, repeatType: "reverse" }}
            />
            {/* Grid lines */}
            <div className="absolute inset-0 grid grid-cols-8 grid-rows-4">
              {[...Array(32)].map((_, i) => (
                <div key={i} className="border border-red-500/20" />
              ))}
            </div>
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <AnimatePresence mode="wait">
      <motion.div
        key={mode}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.5 }}
        className="absolute inset-0 pointer-events-none"
      >
        {getTerrainStyle()}
      </motion.div>
    </AnimatePresence>
  );
}

// Mode Badge Component
function ModeBadge({ mode, urgency }: { mode: string; urgency: number }) {
  const getColor = () => {
    if (urgency >= 3) return "bg-red-500/20 border-red-500 text-red-400";
    if (urgency >= 2) return "bg-orange-500/20 border-orange-500 text-orange-400";
    if (urgency >= 1) return "bg-yellow-500/20 border-yellow-500 text-yellow-400";
    return "bg-[var(--hmi-cyan)]/20 border-[var(--hmi-cyan)] text-[var(--hmi-cyan)]";
  };

  return (
    <motion.div
      className={`px-4 py-2 rounded-lg border ${getColor()} font-[var(--font-heading)] text-sm tracking-wider`}
      animate={urgency >= 3 ? {
        scale: [1, 1.05, 1],
        boxShadow: ["0 0 10px rgba(255,59,59,0.3)", "0 0 20px rgba(255,59,59,0.5)", "0 0 10px rgba(255,59,59,0.3)"]
      } : {}}
      transition={urgency >= 3 ? { duration: 0.5, repeat: Infinity } : {}}
    >
      {mode}
    </motion.div>
  );
}

// Settings Card Component
function SettingCard({ 
  icon, 
  label, 
  value, 
  unit,
  renderVisualization 
}: { 
  icon: string; 
  label: string; 
  value: number | string;
  unit?: string;
  renderVisualization?: () => React.ReactNode;
}) {
  return (
    <motion.div
      className="flex-shrink-0 w-[140px] p-4 rounded-xl bg-[var(--hmi-glass)] backdrop-blur-xl border border-[var(--hmi-glass-border)] hover:border-[var(--hmi-cyan)]/40 transition-colors"
      whileHover={{ scale: 1.02, y: -2 }}
      transition={{ duration: 0.2 }}
    >
      <div className="flex items-center gap-2 mb-2">
        <span className="text-xl">{icon}</span>
        <span className="text-xs text-muted-foreground truncate">{label}</span>
      </div>
      <div className="h-12 flex items-center justify-center">
        {renderVisualization ? renderVisualization() : (
          <span className="text-xl font-[var(--font-heading)] text-[var(--hmi-cyan)]">
            {typeof value === 'number' ? <AnimatedNumber value={value} decimals={typeof value === 'number' && value < 10 ? 1 : 0} /> : value}
            {unit && <span className="text-sm ml-1">{unit}</span>}
          </span>
        )}
      </div>
    </motion.div>
  );
}

// Upload Zone Component
function UploadZone({ 
  onImageUpload, 
  isLoading 
}: { 
  onImageUpload: (file: File) => void; 
  isLoading: boolean;
}) {
  const [isDragging, setIsDragging] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file && file.type.startsWith("image/")) {
      onImageUpload(file);
    }
  }, [onImageUpload]);

  const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      onImageUpload(file);
    }
  }, [onImageUpload]);

  return (
    <motion.div
      className={`relative w-full h-full min-h-[200px] rounded-xl border-2 border-dashed transition-colors cursor-pointer flex flex-col items-center justify-center gap-3
        ${isDragging ? "border-[var(--hmi-cyan)] bg-[var(--hmi-cyan)]/10" : "border-[var(--hmi-glass-border)] hover:border-[var(--hmi-cyan)]/50"}
        ${isLoading ? "pointer-events-none" : ""}`}
      onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
      onDragLeave={() => setIsDragging(false)}
      onDrop={handleDrop}
      onClick={() => fileInputRef.current?.click()}
      whileHover={{ scale: 1.01 }}
    >
      {/* Animated border */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none" style={{ overflow: 'visible' }}>
        <motion.rect
          x="2"
          y="2"
          width="calc(100% - 4px)"
          height="calc(100% - 4px)"
          rx="12"
          fill="none"
          stroke="url(#borderGradient)"
          strokeWidth="2"
          strokeDasharray="10 5"
          animate={{ strokeDashoffset: [0, -15] }}
          transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
        />
        <defs>
          <linearGradient id="borderGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#00d2ff" />
            <stop offset="50%" stopColor="#00ff88" />
            <stop offset="100%" stopColor="#00d2ff" />
          </linearGradient>
        </defs>
      </svg>

      {isLoading ? (
        <div className="flex flex-col items-center gap-3">
          <motion.div
            className="w-12 h-12 border-3 border-[var(--hmi-cyan)] border-t-transparent rounded-full"
            animate={{ rotate: 360 }}
            transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
          />
          <span className="text-sm text-muted-foreground">Analyzing terrain...</span>
        </div>
      ) : (
        <>
          <motion.div
            className="text-4xl"
            animate={{ y: [0, -5, 0] }}
            transition={{ duration: 2, repeat: Infinity }}
          >
            📷
          </motion.div>
          <span className="text-sm text-muted-foreground text-center px-4">
            Drop image here or click to upload
          </span>
          <span className="text-xs text-muted-foreground/60">
            Supports JPG, PNG, WebP
          </span>
        </>
      )}

      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={handleFileSelect}
      />
    </motion.div>
  );
}

// Scanning Animation Component
function ScanningAnimation() {
  return (
    <div className="absolute inset-0 overflow-hidden rounded-xl pointer-events-none">
      <motion.div
        className="absolute left-0 right-0 h-1 bg-gradient-to-r from-transparent via-[var(--hmi-cyan)] to-transparent"
        animate={{ top: ["0%", "100%"] }}
        transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
        style={{ boxShadow: "0 0 20px var(--hmi-cyan)" }}
      />
      <motion.div
        className="absolute inset-0 bg-[var(--hmi-cyan)]/5"
        animate={{ opacity: [0, 0.1, 0] }}
        transition={{ duration: 2, repeat: Infinity }}
      />
    </div>
  );
}

// Image Display Component
function ImageDisplay({ 
  originalImage, 
  annotatedImage,
  isProcessing,
  onZoom,
  onDownload 
}: { 
  originalImage: string | null;
  annotatedImage: string | null;
  isProcessing: boolean;
  onZoom: () => void;
  onDownload: () => void;
}) {
  if (!originalImage) return null;

  return (
    <div className="grid grid-cols-2 gap-4 w-full">
      {/* Original Image */}
      <div className="relative rounded-xl overflow-hidden border border-[var(--hmi-glass-border)]">
        <div className="absolute top-2 left-2 z-10 px-2 py-1 bg-black/60 rounded text-xs text-muted-foreground">
          Original
        </div>
        <img
          src={originalImage}
          alt="Original terrain"
          className="w-full h-48 object-cover"
        />
        {isProcessing && <ScanningAnimation />}
      </div>

      {/* Annotated Image */}
      <div className="relative rounded-xl overflow-hidden border border-[var(--hmi-glass-border)]">
        <div className="absolute top-2 left-2 z-10 px-2 py-1 bg-black/60 rounded text-xs text-muted-foreground">
          AI Analysis
        </div>
        {annotatedImage ? (
          <>
            <img
              src={`data:image/png;base64,${annotatedImage}`}
              alt="AI analyzed terrain"
              className="w-full h-48 object-cover cursor-pointer hover:opacity-90 transition-opacity"
              onClick={onZoom}
            />
            <div className="absolute bottom-2 right-2 flex gap-2">
              <motion.button
                className="p-2 bg-black/60 rounded-lg hover:bg-black/80 transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={(e) => { e.stopPropagation(); onZoom(); }}
              >
                🔍
              </motion.button>
              <motion.button
                className="p-2 bg-black/60 rounded-lg hover:bg-black/80 transition-colors"
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                onClick={(e) => { e.stopPropagation(); onDownload(); }}
              >
                💾
              </motion.button>
            </div>
          </>
        ) : (
          <div className="w-full h-48 flex items-center justify-center bg-[var(--hmi-glass)]">
            {isProcessing ? (
              <div className="flex flex-col items-center gap-2">
                <motion.div
                  className="w-8 h-8 border-2 border-[var(--hmi-cyan)] border-t-transparent rounded-full"
                  animate={{ rotate: 360 }}
                  transition={{ duration: 1, repeat: Infinity, ease: "linear" }}
                />
                <span className="text-xs text-muted-foreground">Processing...</span>
              </div>
            ) : (
              <span className="text-sm text-muted-foreground">Awaiting analysis</span>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Header Component
function Header({ 
  urgency, 
  alertMessage, 
  terrainMode,
  currentTime 
}: { 
  urgency: number; 
  alertMessage: string; 
  terrainMode: string;
  currentTime: string;
}) {
  const getUrgencyStyle = () => {
    if (urgency >= 3) return {
      bg: "bg-red-500/20",
      border: "border-red-500",
      text: "text-red-400",
      glow: "shadow-[0_0_20px_rgba(255,59,59,0.5)]",
      message: "EMERGENCY STOP — OBSTACLE DETECTED"
    };
    if (urgency >= 2) return {
      bg: "bg-orange-500/20",
      border: "border-orange-500",
      text: "text-orange-400",
      glow: "shadow-[0_0_15px_rgba(255,136,0,0.4)]",
      message: "WARNING — ROUGH CONDITIONS"
    };
    if (urgency >= 1) return {
      bg: "bg-yellow-500/20",
      border: "border-yellow-500",
      text: "text-yellow-400",
      glow: "shadow-[0_0_15px_rgba(255,170,0,0.4)]",
      message: "CAUTION — TERRAIN ADJUSTED"
    };
    return {
      bg: "bg-green-500/20",
      border: "border-green-500",
      text: "text-green-400",
      glow: "shadow-[0_0_15px_rgba(0,255,136,0.3)]",
      message: "ALL CLEAR — SAFE TO PROCEED"
    };
  };

  const style = getUrgencyStyle();

  return (
    <header className="flex items-center justify-between px-6 py-4 bg-[var(--hmi-glass)] backdrop-blur-xl border-b border-[var(--hmi-glass-border)]">
      {/* Logo */}
      <div className="flex items-center gap-3">
        <motion.div
          className="w-10 h-10 rounded-lg bg-gradient-to-br from-[var(--hmi-cyan)] to-[var(--hmi-green)] flex items-center justify-center"
          animate={{ 
            boxShadow: ["0 0 10px var(--hmi-cyan-glow)", "0 0 20px var(--hmi-cyan-glow)", "0 0 10px var(--hmi-cyan-glow)"]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <span className="text-xl">🚗</span>
        </motion.div>
        <h1 className="font-[var(--font-heading)] text-xl tracking-wider text-foreground">
          ADAS <span className="text-[var(--hmi-cyan)]">INTELLIGENCE</span>
        </h1>
      </div>

      {/* Urgency Banner */}
      <motion.div
        className={`px-6 py-2 rounded-full border ${style.bg} ${style.border} ${style.glow}`}
        animate={urgency >= 3 ? { scale: [1, 1.02, 1] } : {}}
        transition={urgency >= 3 ? { duration: 0.5, repeat: Infinity } : {}}
      >
        <div className="flex items-center gap-2">
          {urgency >= 3 && (
            <motion.span
              animate={{ opacity: [1, 0.3] }}
              transition={{ duration: 0.3, repeat: Infinity, repeatType: "reverse" }}
            >
              🚨
            </motion.span>
          )}
          <span className={`font-[var(--font-heading)] text-sm tracking-wider ${style.text}`}>
            {alertMessage || style.message}
          </span>
        </div>
      </motion.div>

      {/* Right side info */}
      <div className="flex items-center gap-4">
        <ModeBadge mode={terrainMode} urgency={urgency} />
        <div className="text-right">
          <div className="text-xs text-muted-foreground">System Time</div>
          <div className="font-[var(--font-heading)] text-sm text-[var(--hmi-cyan)]">
            {currentTime}
          </div>
        </div>
      </div>
    </header>
  );
}

// Fullscreen Image Modal
function FullscreenModal({ 
  image, 
  onClose 
}: { 
  image: string; 
  onClose: () => void;
}) {
  return (
    <motion.div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
    >
      <motion.img
        src={`data:image/png;base64,${image}`}
        alt="Fullscreen analysis"
        className="max-w-[90vw] max-h-[90vh] object-contain rounded-xl border border-[var(--hmi-glass-border)]"
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        exit={{ scale: 0.8 }}
      />
      <button
        className="absolute top-4 right-4 p-3 bg-black/60 rounded-full hover:bg-black/80 transition-colors"
        onClick={onClose}
      >
        ✕
      </button>
    </motion.div>
  );
}

// Mini Speedometer for Settings Bar
function MiniSpeedometer({ value, max }: { value: number; max: number }) {
  const percentage = (value / max) * 100;
  return (
    <div className="relative w-10 h-10">
      <svg viewBox="0 0 40 40" className="w-full h-full">
        <circle cx="20" cy="20" r="16" fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="3" />
        <motion.circle
          cx="20"
          cy="20"
          r="16"
          fill="none"
          stroke="var(--hmi-cyan)"
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={`${percentage} ${100 - percentage}`}
          strokeDashoffset="25"
          initial={{ strokeDasharray: "0 100" }}
          animate={{ strokeDasharray: `${percentage} ${100 - percentage}` }}
          transition={{ duration: 0.8 }}
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center text-[10px] font-[var(--font-heading)] text-[var(--hmi-cyan)]">
        {Math.round(value)}
      </span>
    </div>
  );
}

// Vertical Bar Visualization
function VerticalBar({ value, max, color = "var(--hmi-cyan)" }: { value: number; max: number; color?: string }) {
  const percentage = (value / max) * 100;
  return (
    <div className="relative w-6 h-10 bg-white/10 rounded overflow-hidden">
      <motion.div
        className="absolute bottom-0 left-0 right-0 rounded"
        style={{ backgroundColor: color }}
        initial={{ height: 0 }}
        animate={{ height: `${percentage}%` }}
        transition={{ duration: 0.8 }}
      />
    </div>
  );
}

// Wave Animation
function WaveAnimation() {
  return (
    <div className="flex items-end justify-center gap-0.5 h-8">
      {[...Array(5)].map((_, i) => (
        <motion.div
          key={i}
          className="w-1 bg-[var(--hmi-cyan)] rounded-full"
          animate={{ height: [8, 24, 8] }}
          transition={{
            duration: 1,
            repeat: Infinity,
            delay: i * 0.15,
          }}
        />
      ))}
    </div>
  );
}

// Torque Distribution Visualization
function TorqueViz({ distribution }: { distribution: string }) {
  const getFrontRear = () => {
    switch (distribution) {
      case "FWD": return { front: 100, rear: 0 };
      case "RWD": return { front: 0, rear: 100 };
      default: return { front: 50, rear: 50 };
    }
  };
  const { front, rear } = getFrontRear();

  return (
    <div className="flex items-center gap-1">
      <div className="text-[10px] text-muted-foreground">F</div>
      <div className="flex flex-col gap-1">
        <motion.div
          className="h-1.5 bg-[var(--hmi-cyan)] rounded"
          initial={{ width: 0 }}
          animate={{ width: front * 0.3 }}
          transition={{ duration: 0.8 }}
        />
        <motion.div
          className="h-1.5 bg-[var(--hmi-orange)] rounded"
          initial={{ width: 0 }}
          animate={{ width: rear * 0.3 }}
          transition={{ duration: 0.8 }}
        />
      </div>
      <div className="text-[10px] text-muted-foreground">R</div>
    </div>
  );
}

// Main Dashboard Component
export default function ADASDashboard() {
  const [settings, setSettings] = useState<CarSettings>(defaultSettings);
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [annotatedImage, setAnnotatedImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [fullscreenImage, setFullscreenImage] = useState<string | null>(null);
  const [currentTime, setCurrentTime] = useState<string>("");

  // Update time - only on client to avoid hydration mismatch
  useEffect(() => {
    const formatTime = () => {
      const now = new Date();
      return now.toLocaleTimeString("en-US", { hour12: false });
    };
    setCurrentTime(formatTime());
    const interval = setInterval(() => setCurrentTime(formatTime()), 1000);
    return () => clearInterval(interval);
  }, []);

  const handleImageUpload = useCallback(async (file: File) => {
    setError(null);
    setIsLoading(true);
    
    // Create preview
    const reader = new FileReader();
    reader.onload = (e) => setOriginalImage(e.target?.result as string);
    reader.readAsDataURL(file);

    try {
      const formData = new FormData();
      formData.append("image", file);

      const response = await fetch(
        "https://adas-api-82099281155.us-central1.run.app/predict",
        {
          method: "POST",
          body: formData,
        }
      );

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data: ApiResponse = await response.json();
      
      setAnnotatedImage(data.annotated_image_base64);
      setSettings(data.car_settings);
    } catch (err) {
      console.error("[v0] API Error:", err);
      if (err instanceof TypeError && err.message.includes("fetch")) {
        setError("CORS Error: Unable to reach the API. The server may need to allow cross-origin requests.");
      } else {
        setError(err instanceof Error ? err.message : "Failed to analyze image");
      }
    } finally {
      setIsLoading(false);
    }
  }, []);

  const handleDownload = useCallback(() => {
    if (!annotatedImage) return;
    const link = document.createElement("a");
    link.href = `data:image/png;base64,${annotatedImage}`;
    link.download = `adas-analysis-${Date.now()}.png`;
    link.click();
  }, [annotatedImage]);

  const getSpeedColor = () => {
    if (settings.max_speed_kmh < 50) return "#ff3b3b";
    if (settings.max_speed_kmh < 80) return "#ffaa00";
    return "#00ff88";
  };

  return (
    <div className="min-h-screen bg-[#0a0a0a] text-foreground overflow-hidden">
      {/* Carbon fiber texture overlay */}
      <div 
        className="fixed inset-0 pointer-events-none opacity-5"
        style={{
          backgroundImage: `repeating-linear-gradient(
            45deg,
            transparent,
            transparent 2px,
            rgba(255,255,255,0.03) 2px,
            rgba(255,255,255,0.03) 4px
          )`
        }}
      />

      {/* Header */}
      <Header 
        urgency={settings.urgency_level} 
        alertMessage={settings.alert_message}
        terrainMode={settings.terrain_mode}
        currentTime={currentTime}
      />

      {/* Main Content */}
      <main className="p-4 grid grid-cols-12 gap-4 h-[calc(100vh-140px)]">
        {/* Left Panel - Vehicle Simulation */}
        <div className="col-span-3 flex flex-col gap-4">
          <motion.div 
            className="flex-1 rounded-2xl bg-[var(--hmi-glass)] backdrop-blur-xl border border-[var(--hmi-glass-border)] p-4 relative overflow-hidden"
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <h2 className="font-[var(--font-heading)] text-sm tracking-wider text-[var(--hmi-cyan)] mb-4">
              VEHICLE STATUS
            </h2>
            
            {/* Terrain Background */}
            <TerrainBackground mode={settings.terrain_mode} />
            
            {/* Vehicle SVG */}
            <div className="relative z-10 flex justify-center items-center h-[200px]">
              <VehicleSVG 
                settings={settings} 
                isShaking={settings.terrain_mode === "ROUGH"} 
              />
            </div>

            {/* Mode Badge */}
            <div className="flex justify-center mt-4">
              <ModeBadge mode={settings.terrain_mode} urgency={settings.urgency_level} />
            </div>

            {/* Quick Stats */}
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="bg-black/30 rounded-lg p-2 text-center">
                <div className="text-xs text-muted-foreground">Height</div>
                <div className="font-[var(--font-heading)] text-[var(--hmi-cyan)]">
                  <AnimatedNumber value={settings.suspension_height_mm} />mm
                </div>
              </div>
              <div className="bg-black/30 rounded-lg p-2 text-center">
                <div className="text-xs text-muted-foreground">Drive</div>
                <div className="font-[var(--font-heading)] text-[var(--hmi-cyan)]">
                  {settings.torque_distribution}
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Center Panel - Image Analysis */}
        <div className="col-span-5 flex flex-col gap-4">
          <motion.div 
            className="flex-1 rounded-2xl bg-[var(--hmi-glass)] backdrop-blur-xl border border-[var(--hmi-glass-border)] p-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1 }}
          >
            <h2 className="font-[var(--font-heading)] text-sm tracking-wider text-[var(--hmi-cyan)] mb-4">
              TERRAIN ANALYSIS
            </h2>

            {error && (
              <motion.div
                className="mb-4 p-3 rounded-lg bg-red-500/20 border border-red-500 text-red-400 text-sm"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
              >
                ⚠️ {error}
              </motion.div>
            )}

            {!originalImage ? (
              <UploadZone onImageUpload={handleImageUpload} isLoading={isLoading} />
            ) : (
              <div className="space-y-4">
                <ImageDisplay
                  originalImage={originalImage}
                  annotatedImage={annotatedImage}
                  isProcessing={isLoading}
                  onZoom={() => annotatedImage && setFullscreenImage(annotatedImage)}
                  onDownload={handleDownload}
                />
                
                {/* Upload new button */}
                <motion.button
                  className="w-full py-2 rounded-lg bg-[var(--hmi-cyan)]/20 border border-[var(--hmi-cyan)]/40 text-[var(--hmi-cyan)] font-[var(--font-heading)] text-sm tracking-wider hover:bg-[var(--hmi-cyan)]/30 transition-colors"
                  whileHover={{ scale: 1.01 }}
                  whileTap={{ scale: 0.99 }}
                  onClick={() => {
                    setOriginalImage(null);
                    setAnnotatedImage(null);
                    setError(null);
                  }}
                >
                  ANALYZE NEW IMAGE
                </motion.button>

                {/* Alert Message */}
                {settings.alert_message && settings.alert_message !== "System Ready" && (
                  <motion.div
                    className={`p-3 rounded-lg text-sm text-center font-[var(--font-heading)] tracking-wider ${
                      settings.urgency_level >= 3 ? "bg-red-500/20 text-red-400 border border-red-500" :
                      settings.urgency_level >= 2 ? "bg-orange-500/20 text-orange-400 border border-orange-500" :
                      settings.urgency_level >= 1 ? "bg-yellow-500/20 text-yellow-400 border border-yellow-500" :
                      "bg-green-500/20 text-green-400 border border-green-500"
                    }`}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    {settings.alert_message}
                  </motion.div>
                )}
              </div>
            )}
          </motion.div>
        </div>

        {/* Right Panel - Instrument Cluster */}
        <div className="col-span-4 flex flex-col gap-4">
          <motion.div 
            className="flex-1 rounded-2xl bg-[var(--hmi-glass)] backdrop-blur-xl border border-[var(--hmi-glass-border)] p-4"
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            <h2 className="font-[var(--font-heading)] text-sm tracking-wider text-[var(--hmi-cyan)] mb-4">
              INSTRUMENT CLUSTER
            </h2>

            {/* Main Speedometer */}
            <div className="flex justify-center mb-6">
              <CircularGauge
                value={settings.max_speed_kmh}
                maxValue={200}
                label="MAX SPEED"
                unit=" km/h"
                color={getSpeedColor()}
                size="large"
              />
            </div>

            {/* Secondary Gauges */}
            <div className="flex justify-around">
              <CircularGauge
                value={settings.traction_control}
                maxValue={1}
                label="Traction"
                color="#00d2ff"
                size="small"
              />
              <CircularGauge
                value={settings.brake_sensitivity}
                maxValue={1}
                label="Brake"
                color="#ffaa00"
                size="small"
              />
              <CircularGauge
                value={settings.suspension_stiffness}
                maxValue={1}
                label="Stiffness"
                color="#00ff88"
                size="small"
              />
            </div>

            {/* Additional Stats */}
            <div className="mt-6 grid grid-cols-2 gap-3">
              <div className="bg-black/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">ABS Level</div>
                <div className="flex items-center gap-2">
                  <motion.div
                    className="w-3 h-3 rounded-full bg-[var(--hmi-cyan)]"
                    animate={{ scale: [1, 1.2, 1], opacity: [1, 0.7, 1] }}
                    transition={{ duration: 1, repeat: Infinity }}
                  />
                  <span className="font-[var(--font-heading)] text-[var(--hmi-cyan)]">
                    <AnimatedNumber value={settings.abs_aggressiveness * 100} />%
                  </span>
                </div>
              </div>
              <div className="bg-black/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">Follow Distance</div>
                <span className="font-[var(--font-heading)] text-[var(--hmi-cyan)]">
                  <AnimatedNumber value={settings.safe_following_distance_m} />m
                </span>
              </div>
              <div className="bg-black/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">Acceleration</div>
                <span className="font-[var(--font-heading)] text-[var(--hmi-cyan)]">
                  <AnimatedNumber value={settings.acceleration_rate * 100} />%
                </span>
              </div>
              <div className="bg-black/30 rounded-lg p-3">
                <div className="text-xs text-muted-foreground mb-1">Steering</div>
                <span className="font-[var(--font-heading)] text-[var(--hmi-cyan)]">
                  <AnimatedNumber value={settings.steering_responsiveness * 100} />%
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      </main>

      {/* Bottom Settings Bar */}
      <motion.div 
        className="fixed bottom-0 left-0 right-0 bg-[var(--hmi-glass)] backdrop-blur-xl border-t border-[var(--hmi-glass-border)] p-4"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.3 }}
      >
        <div className="flex gap-4 overflow-x-auto pb-2 scrollbar-hide">
          <SettingCard
            icon="🏔️"
            label="Suspension"
            value={settings.suspension_height_mm}
            unit="mm"
            renderVisualization={() => (
              <VerticalBar value={settings.suspension_height_mm} max={260} />
            )}
          />
          <SettingCard
            icon="🚀"
            label="Max Speed"
            value={settings.max_speed_kmh}
            unit="km/h"
            renderVisualization={() => (
              <MiniSpeedometer value={settings.max_speed_kmh} max={200} />
            )}
          />
          <SettingCard
            icon="🔧"
            label="Traction"
            value={settings.traction_control}
            renderVisualization={() => (
              <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden">
                <motion.div
                  className="h-full bg-[var(--hmi-cyan)] rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${settings.traction_control * 100}%` }}
                  transition={{ duration: 0.8 }}
                />
              </div>
            )}
          />
          <SettingCard
            icon="🛞"
            label="Drive Mode"
            value={settings.torque_distribution}
            renderVisualization={() => (
              <TorqueViz distribution={settings.torque_distribution} />
            )}
          />
          <SettingCard
            icon="🛑"
            label="Brake"
            value={settings.brake_sensitivity}
            renderVisualization={() => (
              <motion.div
                className="w-8 h-8 rounded-full border-4 border-[var(--hmi-orange)]"
                animate={{
                  borderWidth: [4, 6, 4],
                  opacity: [0.6, 1, 0.6],
                }}
                transition={{ duration: 1, repeat: Infinity }}
              />
            )}
          />
          <SettingCard
            icon="⚙️"
            label="ABS"
            value={settings.abs_aggressiveness}
            renderVisualization={() => (
              <motion.div
                className="w-8 h-8 rounded-full bg-[var(--hmi-cyan)]/30 flex items-center justify-center"
                animate={{
                  scale: [1, 1.1, 1],
                  boxShadow: ["0 0 0 0 var(--hmi-cyan-glow)", "0 0 10px 3px var(--hmi-cyan-glow)", "0 0 0 0 var(--hmi-cyan-glow)"]
                }}
                transition={{ duration: 1.5, repeat: Infinity }}
              >
                <span className="text-xs font-bold text-[var(--hmi-cyan)]">
                  {Math.round(settings.abs_aggressiveness * 100)}
                </span>
              </motion.div>
            )}
          />
          <SettingCard
            icon="📏"
            label="Follow Dist"
            value={settings.safe_following_distance_m}
            unit="m"
            renderVisualization={() => (
              <div className="flex items-center gap-1">
                {[...Array(3)].map((_, i) => (
                  <motion.div
                    key={i}
                    className="w-1 h-4 bg-[var(--hmi-cyan)] rounded"
                    animate={{ opacity: [0.3, 1, 0.3] }}
                    transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                  />
                ))}
              </div>
            )}
          />
          <SettingCard
            icon="〰️"
            label="Damping"
            value={settings.damping_rate}
            renderVisualization={() => <WaveAnimation />}
          />
          <SettingCard
            icon="🎯"
            label="Steering"
            value={settings.steering_responsiveness}
            renderVisualization={() => (
              <motion.div
                className="w-8 h-8 border-2 border-[var(--hmi-cyan)] rounded-full flex items-center justify-center"
                animate={{ rotate: [0, 15, 0, -15, 0] }}
                transition={{ duration: 2, repeat: Infinity }}
              >
                <div className="w-0.5 h-4 bg-[var(--hmi-cyan)]" />
              </motion.div>
            )}
          />
        </div>
      </motion.div>

      {/* Fullscreen Modal */}
      <AnimatePresence>
        {fullscreenImage && (
          <FullscreenModal 
            image={fullscreenImage} 
            onClose={() => setFullscreenImage(null)} 
          />
        )}
      </AnimatePresence>
    </div>
  );
}
